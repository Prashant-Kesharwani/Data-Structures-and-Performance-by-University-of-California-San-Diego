package spelling;

import java.util.TreeSet;


public class DictionaryBST implements Dictionary 
{
   private TreeSet<String> dict;

    public DictionaryBST() {
        this.dict = new TreeSet <>();
    }


    public boolean addWord(String word) {
        word = word.toLowerCase();
        if(!dict.contains(word))
            return dict.add(word);
        return false;
    }

    /** Return the number of words in the dictionary */
    public int size() {
        return dict.size();
    }

    /** Is this a word according to this dictionary? */
    public boolean isWord(String s) {
        return dict.contains(s.toLowerCase());
    }

}
