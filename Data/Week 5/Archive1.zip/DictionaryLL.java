package spelling;

import java.util.LinkedList;


public class DictionaryLL implements Dictionary {

	private LinkedList<String> dict;

    public DictionaryLL() {
        this.dict = new LinkedList<>();
    }

    public boolean addWord(String word) {
        word = word.toLowerCase();
        if(!dict.contains(word))
            return dict.add(word);
        return false;
    }

    /** Return the number of words in the dictionary */
    public int size() {
        return dict.size();
    }

    /** Is this a word according to this dictionary? */
    public boolean isWord(String s) {
        return dict.contains(s.toLowerCase());
    }

    
}
